"Resource/UI/ClassSelection.res"
{
    "class"
    {
        "ControlName"   "ImagePanel"
        "fieldName"     "ShadeBG"
        "xpos"          "0"
        "ypos"          "0"
        "wide"          "f0"
        "tall"          "480"
        "autoResize"    "0"
        "pinCorner"     "0"
        "visible"       "1"
        "enabled"       "1"
        "tabPosition"   "0"
        "fillcolor"     "0 0 0 128"
    }
    
    "SysMenu"
    {
        "ControlName"   "Menu"
        "fieldName"     "SysMenu"
        "xpos"          "0"
        "ypos"          "0"
        "wide"          "64"
        "tall"          "24"
        "autoResize"    "0"
        "pinCorner"     "0"
        "visible"       "0"
        "enabled"       "0"
        "tabPosition"   "0"
    }
    
    "SidePanelBG"
    {
        "ControlName"   "ImagePanel"
        "fieldName"     "SidePanelBG"
        "xpos"          "c-90"
        "ypos"          "0"
        "zpos"          "0"
        "wide"          "180"
        "tall"          "f0"
        "visible"       "1"
        "enabled"       "1"
        "scaleImage"    "1"
        "fillcolor"     "25 25 25 255"
    }
    
    "random"
    {
        "ControlName"       "CExLabel"
        "fieldName"         "random"
        "xpos"              "9999"
        "ypos"              "9999"
        "zpos"              "6"
        "wide"              "150"
        "tall"              "16"
        "autoResize"        "0"
        "pinCorner"         "2"
        "visible"           "1"
        "enabled"           "1"
        "tabPosition"       "0"
        "labelText"         "&R  Random"    [$WIN32]
        "textAlignment"     "west"
        "Command"           "joinclass random"
        "Default"           "0"
        "font"              "CerbeticaBold16"   
        "scaleImage"        "1"
        "paintbackground"   "0"
        
        "fgcolor"                   "TanDark"
        "defaultFgColor_override"   "TanDark"
        "armedFgColor_override"     "TanDark"
        "depressedFgColor_override" "TanDark"
        "selectedFgColor_override"  "TanLight"
            
        "sound_depressed"   "UI/buttonclick.wav"
        "sound_released"    "UI/buttonclickrelease.wav"
        "sound_armed"       "UI/buttonrollover.wav"
        
        
        "stayselectedonclick"   "1"
        "Default"               "1"
        "selectonhover"         "1"
        "keyboardinputenabled"  "0"
    }
    
        
    "Offense"
    {
        "ControlName"   "CExLabel"
        "fieldName"     "Offense"
        "xpos"          "c-45"
        "ypos"          "150"
        "zpos"          "2"
        "wide"          "90"
        "tall"          "12"
        "tall_lodef"            "22"
        "autoResize"    "1"
        "pinCorner"     "2"
        "visible"       "1"
        "enabled"       "1"
        "tabPosition"   "0"
        "labelText"     "Generalists"
        "textAlignment" "center"
        "font"          "CerbeticaBold12"
        "font_lodef"            "MenuMainTitle"
        "fgcolor"       "TanDark"
        "fgcolor_lodef" "TanLight"
    }
    "scout"
    {
        "ControlName"       "CExImageButton"
        "fieldName"         "scout"
        "xpos"              "c-51"
        "ypos"              "170"
        "zpos"              "6"
        "wide"              "100"
        "tall"              "16"
        "autoResize"        "0"
        "pinCorner"         "2"
        "visible"           "1"
        "enabled"           "1"
        "tabPosition"       "0"
        "labelText"         "Scout"    [$WIN32]
        "textAlignment"     "center"
        "Command"           "joinclass scout"
        "font"              "CerbeticaBold20"
        "scaleImage"        "1"
        "paintbackground"   "0"
        
        "fgcolor"                   "Health Normal"
        "defaultFgColor_override"   "Health Normal"
        "armedFgColor_override"     "Health Normal"
        "depressedFgColor_override" "Health Normal"
        "selectedFgColor_override"  "Health Normal"
            
        "sound_depressed"   "UI/buttonclick.wav"
        "sound_released"    "vo/scout_mvm_loot_rare01.wav"
        "sound_armed"       "UI/buttonrollover.wav"
        
        
        "stayselectedonclick"   "1"
        "Default"               "1"
        "selectonhover"         "1"
        "keyboardinputenabled"  "0"

    }
    "soldier"
        {
        "ControlName"       "CExImageButton"
        "fieldName"         "soldier"
        "xpos"              "c-51"
        "ypos"              "184"
        "zpos"              "6"
        "wide"              "100"
        "tall"              "16"
        "autoResize"        "0"
        "pinCorner"         "2"
        "visible"           "1"
        "enabled"           "1"
        "tabPosition"       "0"
        "labelText"         "Soldier"   [$WIN32]
        "textAlignment"     "center"
        "Command"           "joinclass soldier"
        "Default"           "0"
        "font"              "CerbeticaBold20"
        "scaleImage"        "1"
        "paintbackground"   "0"
        
        "fgcolor"                   "Health Normal"
        "defaultFgColor_override"   "Health Normal"
        "armedFgColor_override"     "Health Normal"
        "depressedFgColor_override" "Health Normal"
        "selectedFgColor_override"  "Health Normal"
            
        "sound_depressed"   "UI/buttonclick.wav"
        "sound_released"    "vo/soldier_mvm_loot_godlike03.wav"
        "sound_armed"       "UI/buttonrollover.wav"
        
        
        "stayselectedonclick"   "1"
        "Default"               "1"
        "selectonhover"         "1"
        "keyboardinputenabled"  "0"

        }
     "demoman"
        {
        "ControlName"       "CExImageButton"
        "fieldName"         "demoman"
        "xpos"              "c-51"
        "ypos"              "198"
        "zpos"              "6"
        "wide"              "100"
        "tall"              "16"
        "autoResize"        "0"
        "pinCorner"         "2"
        "visible"           "1"
        "enabled"           "1"
        "tabPosition"       "0"
        "labelText"         "Demoman"   [$WIN32]
        "textAlignment"     "center"
        "Command"           "joinclass demoman"
        "Default"           "0"
        "font"              "CerbeticaBold20"   
        "scaleImage"        "1"
        "paintbackground"   "0"
        
        "fgcolor"                   "Health Normal"
        "defaultFgColor_override"   "Health Normal"
        "armedFgColor_override"     "Health Normal"
        "depressedFgColor_override" "Health Normal"
        "selectedFgColor_override"  "Health Normal"
            
        "sound_depressed"   "UI/buttonclick.wav"
        "sound_released"    "vo/demoman_dominationdemoman01.wav"
        "sound_armed"       "UI/buttonrollover.wav"
        
        
        "stayselectedonclick"   "1"
        "Default"               "1"
        "selectonhover"         "1"
        "keyboardinputenabled"  "0"
        }
     "medic"
        {
        "ControlName"       "CExImageButton"
        "fieldName"         "medic"
        "xpos"              "c-51"
        "ypos"              "212"
        "zpos"              "6"
        "wide"              "100"
        "tall"              "16"
        "autoResize"        "0"
        "pinCorner"         "2"
        "visible"           "1"
        "enabled"           "1"
        "tabPosition"       "0"
        "labelText"         "Medic" [$WIN32]
        "textAlignment"     "center"
        "Command"           "joinclass medic"
        "Default"           "0"
        "font"              "CerbeticaBold20"   
        "scaleImage"        "1"
        "paintbackground"   "0"
        
        "fgcolor"                   "Health Normal"
        "defaultFgColor_override"   "Health Normal"
        "armedFgColor_override"     "Health Normal"
        "depressedFgColor_override" "Health Normal"
        "selectedFgColor_override"  "Health Normal"
            
        "sound_depressed"   "UI/buttonclick.wav"
        "sound_released"    "vo/medic_mvm_say_ready02.wav"
        "sound_armed"       "UI/buttonrollover.wav"
        
        
        "stayselectedonclick"   "1"
        "Default"               "1"
        "selectonhover"         "1"
        "keyboardinputenabled"  "0"
        }

    
    "Defense"
        {
        "ControlName"   "CExLabel"
        "fieldName"     "Defense"
        "xpos"          "c-45"
        "ypos"          "245"
        "zpos"          "2"
        "wide"          "90"
        "tall"          "12"
        "tall_lodef"            "22"
        "autoResize"    "1"
        "pinCorner"     "2"
        "visible"       "1"
        "enabled"       "1"
        "tabPosition"   "0"
        "labelText"     "Specialists"
        "textAlignment" "center"
        "font"          "CerbeticaBold12"
        "font_lodef"            "MenuMainTitle"
        "fgcolor"       "TanDark"
        "fgcolor_lodef" "TanLight"
        }
    "pyro"
        {
        "ControlName"       "CExImageButton"
        "fieldName"         "pyro"
        "xpos"              "c-51"
        "ypos"              "265"
        "zpos"              "6"
        "wide"              "100"
        "tall"              "16"
        "autoResize"        "0"
        "pinCorner"         "2"
        "visible"           "1"
        "enabled"           "1"
        "tabPosition"       "0"
        "labelText"         "Pyro"  [$WIN32]
        "textAlignment"     "center"
        "Command"           "joinclass pyro"
        "Default"           "0"
        "font"              "CerbeticaBold16"   
        "scaleImage"        "1"
        "paintbackground"   "0"
        
        "fgcolor"                   "TanDark"
        "defaultFgColor_override"   "TanDark"
        "armedFgColor_override"     "TanDark"
        "depressedFgColor_override" "TanDark"
        "selectedFgColor_override"  "TanLight"
            
        "sound_depressed"   "UI/buttonclick.wav"
        "sound_released"    "vo/pyro_laughevil04.wav"
        "sound_armed"       "UI/buttonrollover.wav"
        
        
        "stayselectedonclick"   "1"
        "Default"               "1"
        "selectonhover"         "1"
        "keyboardinputenabled"  "0"

        }
   
        
    "heavyweapons"
        {
        "ControlName"       "CExLabel"
        "fieldName"         "heavyweapons"
        "xpos"              "c-51"
        "ypos"              "278"
        "zpos"              "6"
        "wide"              "100"
        "tall"              "16"
        "autoResize"        "0"
        "pinCorner"         "2"
        "visible"           "1"
        "enabled"           "1"
        "tabPosition"       "0"
        "labelText"         "Heavy" [$WIN32]
        "textAlignment"     "center"
        "Command"           "joinclass heavyweapons"
        "Default"           "0"
        "font"              "CerbeticaBold16"   
        "scaleImage"        "1"
        "paintbackground"   "0"
        
        "fgcolor"                   "TanDark"
        "defaultFgColor_override"   "TanDark"
        "armedFgColor_override"     "TanDark"
        "depressedFgColor_override" "TanDark"
        "selectedFgColor_override"  "TanLight"
            
        "sound_depressed"   "UI/buttonclick.wav"
        "sound_released"    "vo/heavy_fairyprincess04.wav"
        "sound_armed"       "UI/buttonrollover.wav"
        
        
        "stayselectedonclick"   "1"
        "Default"               "1"
        "selectonhover"         "1"
        "keyboardinputenabled"  "0"
        }
        
    "engineer"
    {
        "ControlName"       "CExLabel"
        "fieldName"         "engineer"
        "xpos"              "c-51"
        "ypos"              "292"
        "zpos"              "6"
        "wide"              "100"
        "tall"              "16"
        "autoResize"        "0"
        "pinCorner"         "2"
        "visible"           "1"
        "enabled"           "1"
        "tabPosition"       "0"
        "labelText"         "Engineer"  [$WIN32]
        "textAlignment"     "center"
        "Command"           "joinclass engineer"
        "Default"           "0"
        "font"              "CerbeticaBold16"   
        "scaleImage"        "1"
        "paintbackground"   "0"
        
        "fgcolor"                   "TanDark"
        "defaultFgColor_override"   "TanDark"
        "armedFgColor_override"     "TanDark"
        "depressedFgColor_override" "TanDark"
        "selectedFgColor_override"  "TanLight"
            
        "sound_depressed"   "UI/buttonclick.wav"
        "sound_released"    "vo/engineer_goldenwrenchkill03.wav"
        "sound_armed"       "UI/buttonrollover.wav"
        
        
        "stayselectedonclick"   "1"
        "Default"               "1"
        "selectonhover"         "1"
        "keyboardinputenabled"  "0"
    }
    "sniper"
        {
        "ControlName"       "CExImageButton"
        "fieldName"         "sniper"
        "xpos"              "c-51"
        "ypos"              "306"
        "zpos"              "6"
        "wide"              "100"
        "tall"              "16"
        "autoResize"        "0"
        "pinCorner"         "2"
        "visible"           "1"
        "enabled"           "1"
        "tabPosition"       "0"
        "labelText"         "Sniper"    [$WIN32]
        "textAlignment"     "center"
        "Command"           "joinclass sniper"
        "Default"           "0"
        "font"              "CerbeticaBold16"   
        "scaleImage"        "1"
        "paintbackground"   "0"
        
        "fgcolor"                   "TanDark"
        "defaultFgColor_override"   "TanDark"
        "armedFgColor_override"     "TanDark"
        "depressedFgColor_override" "TanDark"
        "selectedFgColor_override"  "TanLight"
            
        "sound_depressed"   "UI/buttonclick.wav"
        "sound_released"    "vo/sniper_mvm_loot_rare05.wav"
        "sound_armed"       "UI/buttonrollover.wav"
        
        
        "stayselectedonclick"   "1"
        "Default"               "1"
        "selectonhover"         "1"
        "keyboardinputenabled"  "0"
        }
      "spy"
        {
        "ControlName"       "CExImageButton"
        "fieldName"         "spy"
        "xpos"              "c-51"
        "ypos"              "320"
        "zpos"              "6"
        "wide"              "100"
        "tall"              "16"
        "autoResize"        "0"
        "pinCorner"         "2"
        "visible"           "1"
        "enabled"           "1"
        "tabPosition"       "0"
        "labelText"         "Spy"   [$WIN32]
        "textAlignment"     "center"
        "Command"           "joinclass spy"
        "Default"           "0"
        "font"              "CerbeticaBold16"   
        "scaleImage"        "1"
        "paintbackground"   "0"
        
        "fgcolor"                   "TanDark"
        "defaultFgColor_override"   "TanDark"
        "armedFgColor_override"     "TanDark"
        "depressedFgColor_override" "TanDark"
        "selectedFgColor_override"  "TanLight"
            
        "sound_depressed"   "UI/buttonclick.wav"
        "sound_released"    "vo/spy_sf12_goodmagic08.wav"
        "sound_armed"       "UI/buttonrollover.wav"
        
        
        "stayselectedonclick"   "1"
        "Default"               "1"
        "selectonhover"         "1"
        "keyboardinputenabled"  "0"
        }
    
    "Support"
    {
        "ControlName"   "CExLabel"
        "fieldName"     "Support"
        "xpos"          "9999"
        "ypos"          "9999"
        "zpos"          "2"
        "wide"          "90"
        "tall"          "12"
        "autoResize"    "1"
        "pinCorner"     "2"
        "visible"       "1"
        "enabled"       "1"
        "tabPosition"   "0"
        "labelText"     "#TF_Support"
        "textAlignment" "left"
        "font"          "MenuClassBuckets"
        "font_lodef"            "MenuMainTitle"
        "fgcolor"       "TanDark"
        "fgcolor_lodef" "TanLight"
    }


  

    "CancelButton" [$WIN32] 
    {
        "ControlName"   "CExButton"
        "fieldName"     "CancelButton"
        "xpos"          "9999"
        "ypos"          "9999"
        "zpos"          "6"
        "wide"          "75"
        "tall"          "25"
        "autoResize"    "0"
        "pinCorner"     "2"
        "visible"       "1"
        "enabled"       "1"
        "tabPosition"   "0"
        "labelText"     "&Q  CANCEL"
        "textAlignment" "center"
        "paintbackground""0"
        "Command"       "vguicancel"
        "font"          "CerbeticaBold16"
        
        "fgcolor"                   "TanLight"
    }
    
    "EditLoadoutButton" [$WIN32] 
    {
        "ControlName"   "CExButton"
        "fieldName"     "EditLoadoutButton"
        "xpos"          "9999"
        "ypos"          "9999"
        "zpos"          "6"
        "wide"          "100"
        "tall"          "25"
        "autoResize"    "0"
        "pinCorner"     "2"
        "visible"       "1"
        "enabled"       "1"
        "tabPosition"   "0"
        "paintbackground""0"
        "labelText"     "EDIT LOADOUT (&E)"
        "textAlignment" "west"
        "Command"       "openloadout"
        "font"          "CerbeticaBold16"
    }
    "LoadoutButtonBackground"
    {
        "ControlName"   "ImagePanel"
        "fieldName"     "LoadoutButtonBackground"
        "xpos"          "c98"
        "ypos"          "c114"
        "wide"          "20"
        "tall"          "0"
    }
    "ResetButton" [$WIN32] 
    {
        "ControlName"   "CExButton"
        "fieldName"     "ResetButton"
        "xpos"          "r470"
        "ypos"          "r38"
        "zpos"          "6"
        "wide"          "110"
        "tall"          "25"
        "autoResize"    "0"
        "pinCorner"     "2"
        "visible"       "0"
        "enabled"       "1"
        "tabPosition"   "0"
        "labelText"     "#TF_ClassMenu_Reset"
        "paintbackground""0"
        "textAlignment" "center"
        "Command"       "resetclass"
        "font"          "CerbeticaBold16"
    }

    "ClassMenuSelect"
    {
        "ControlName"   "CExLabel"
        "fieldName"     "ClassMenuSelect"
        "xpos"          "9999"
        "ypos"          "9999"
        "zpos"          "5"
        "wide"          "255"
        "tall"          "30"
        "autoResize"    "0"
        "pinCorner"     "0"
        "visible"       "1"
        "visible_lodef" "0"
        "enabled"       "1"
        "labelText"     "#TF_SelectAClass"
        "textAlignment" "center"
        "font"          "CerbeticaBold28"
        "fgcolor"       "HudOffWhite"
    }
    
    "MenuBG"
    {
        "ControlName"   "CModelPanel"
        "fieldName"     "MenuBG"
        "xpos"          "9999"
        "ypos"          "9999"
        "zpos"          "0"     
        "wide"          "f0"
        "tall"          "480"
        "autoResize"    "0"
        "pinCorner"     "0"
        "visible"       "1"
        "enabled"       "1"
        "fov"           "16"
        
        "model"
        {
            "modelname" "models/vgui/UI_class01.mdl"
            "skin"      "0"
            "angles_x" "0"
            "angles_y" "180"
            "angles_z" "0"
            "origin_x" "365"
            "origin_x_lodef" "415"
            "origin_x_hidef" "380"
            "origin_y" "0"
            "origin_z" "-40"
        }
    }   

    "Hint"
    {   
        "ControlName"   "CExLabel"
        "fieldName"     "Hint"
        "xpos"          "c-300"
        "xpos_hidef"    "c-287"
        "xpos_lodef"    "c-260"
        "ypos"          "95"
        "ypos_hidef"    "101"
        "ypos_lodef"    "115"
        "zpos"          "2"
        "wide"          "600"
        "tall"          "50"
        "tall_lodef"    "30"
        "autoResize"    "1"
        "pinCorner"     "2"
        "visible"       "0"
        "enabled"       "1"
        "tabPosition"   "0"
        "labelText"     "%hint%"
        "textAlignment" "left"
        "wrap"          "1"
        "font"          "HudFontMediumSmallSecondary"
        "font_lodef"    "HudFontMediumSmallSecondary"
        "fgcolor"       "HudTrainingHint"
        "fgcolor_lodef" "HudTrainingHint"
    }
    
    "ShadedBar"
    {
        "ControlName"   "ImagePanel"
        "fieldName"     "ShadedBar"
        "xpos"          "9999"
        "ypos"          "r50"
        "ypos_lodef"            "r74"
        "ypos_hidef"            "r65"
        "zpos"          "4"
        "wide"          "f0"
        "tall"          "50"
        "tall_lodef"            "74"
        "tall_hidef"            "65"
        "autoResize"    "0"
        "pinCorner"     "0"
        "visible"       "1"
        "enabled"       "1"
        "tabPosition"   "0" 
        "image"         "loadout_bottom_gradient"
        "tileImage"     "1"
        "PaintBackgroundType"   "0"
    }       
    
    "Footer" [$X360]
    {
        "ControlName"       "CTFFooter"
        "fieldName"         "Footer"
        "zpos"              "6"
        "tall"              "80"
        "button_separator"  "10"
        "button_separator_lodef"    "5"
        "buttongap"         "50"
        "buttongap_hidef"       "35"
        "buttongap_lodef"           "18"
        "textadjust"        "3"
        "textadjust_lodef"      "0"
        "buttonoffsety"     "20"
        "buttonoffsety_hidef"       "0"
        "buttonoffsety_lodef"       "18"
        "center"            "0"
        "button_pin_right_lodef"    "55"
        "fonttext"          "MatchmakingDialogMenuLarge"
        "fonttext_lodef"            "MatchmakingDialogMenuSmall"
        "fgcolor"           "HudOffWhite"   
        
        "button"
        {
            "name"      "cancel"
            "text"      "#GameUI_Cancel"
            "icon"      "#GameUI_Icons_B_BUTTON"    
        }
        
        "button"
        {
            "name"      "nextprev"
            "text"      "#TF_NextPrev"
            "icon"      "#GameUI_Icons_DPAD"    
        }               
        
        "button"
        {
            "name"      "select"
            "text"      "#GameUI_Select"
            "icon"      "#GameUI_Icons_A_BUTTON"    
        }
    }
    
    "localPlayerImage" [$WIN32]
    {
        "ControlName"   "CTFImagePanel"
        "fieldName"     "localPlayerImage"
        "xpos"          "9999"
        "ypos"          "9999"
        "zpos"          "9"
        "wide"          "45"
        "tall"          "90"
        "visible"       "0"
        "enabled"       "0"
        "image"         ""  
        "scaleImage"    "1" 
    }
    
    "localPlayerBG"
    {
        "ControlName"   "CTFImagePanel"
        "fieldName"     "localPlayerBG"
        "xpos"          "9999"
        "ypos"          "99999"
        "zpos"          "2"
        "wide"          "55"
        "tall"          "80"
        "autoResize"    "0"
        "pinCorner"     "0"
        "visible"       "0"
        "enabled"       "1"
        "image"         "../hud/color_panel_clear"
        "scaleImage"    "1" 
        "teambg_2"      "../hud/color_panel_clear"
        "teambg_3"      "../hud/color_panel_clear"
            
        "src_corner_height"     "23"            // pixels inside the image
        "src_corner_width"      "23"
                
        "draw_corner_width"     "5"             // screen size of the corners ( and sides ), proportional
        "draw_corner_height"    "5" 
    }
    
    "countImage0" [$WIN32]
    {
        "ControlName"   "CTFImagePanel"
        "fieldName"     "countImage0"
        "xpos"          "9999"
        "ypos"          "9999"
        "zpos"          "9"
        "wide"          "30"
        "tall"          "60"
        "visible"       "0"
        "enabled"       "1"
        "image"         ""  
        "scaleImage"    "1" 
    }                           
    
    "countImage1" [$WIN32]
    {
        "ControlName"   "CTFImagePanel"
        "fieldName"     "countImage1"
        "xpos"          "9999"
        "ypos"          "9999"
        "zpos"          "9"
        "wide"          "30"
        "tall"          "60"
        "visible"       "0"
        "enabled"       "1"
        "image"         ""  
        "scaleImage"    "1" 
    }
    
    "countImage2" [$WIN32]
    {
        "ControlName"   "CTFImagePanel"
        "fieldName"     "countImage2"
        "xpos"          "9999"
        "ypos"          "9999"
        "zpos"          "9"
        "wide"          "30"
        "tall"          "60"
        "visible"       "0"
        "enabled"       "1"
        "image"         ""  
        "scaleImage"    "1" 
    }
    
    "countImage3" [$WIN32]
    {
        "ControlName"   "CTFImagePanel"
        "fieldName"     "countImage3"
        "xpos"          "9999"
        "ypos"          "9999"
        "zpos"          "9"
        "wide"          "30"
        "tall"          "60"
        "visible"       "0"
        "enabled"       "1"
        "image"         ""  
        "scaleImage"    "1" 
    }
    
    "countImage4" [$WIN32]
    {
        "ControlName"   "CTFImagePanel"
        "fieldName"     "countImage4"
        "xpos"          "9999"
        "ypos"          "9999"
        "zpos"          "9"
        "wide"          "30"
        "tall"          "60"
        "visible"       "0"
        "enabled"       "1"
        "image"         ""  
        "scaleImage"    "1" 
    }
    
    "countImage5" [$WIN32]
    {
        "ControlName"   "CTFImagePanel"
        "fieldName"     "countImage5"
        "xpos"          "9999"
        "ypos"          "9999"
        "zpos"          "9"
        "wide"          "30"
        "tall"          "60"
        "visible"       "0"
        "enabled"       "1"
        "image"         ""  
        "scaleImage"    "1" 
    }
    
    "countImage6" [$WIN32]
    {
        "ControlName"   "CTFImagePanel"
        "fieldName"     "countImage6"
        "xpos"          "9999"
        "ypos"          "9999"
        "zpos"          "9"
        "wide"          "30"
        "tall"          "60"
        "visible"       "0"
        "enabled"       "1"
        "image"         ""  
        "scaleImage"    "1" 
    }
    
    "countImage7" [$WIN32]
    {
        "ControlName"   "CTFImagePanel"
        "fieldName"     "countImage7"
        "xpos"          "9999"
        "ypos"          "9999"
        "zpos"          "9"
        "wide"          "30"
        "tall"          "60"
        "visible"       "0"
        "enabled"       "1"
        "image"         ""  
        "scaleImage"    "1" 
    }
    
    "countImage8" [$WIN32]
    {
        "ControlName"   "CTFImagePanel"
        "fieldName"     "countImage8"
        "xpos"          "9999"
        "ypos"          "9999"
        "zpos"          "9"
        "wide"          "30"
        "tall"          "60"
        "visible"       "0"
        "enabled"       "1"
        "image"         ""  
        "scaleImage"    "1" 
    }
    
    "countImage9" [$WIN32]
    {
        "ControlName"   "CTFImagePanel"
        "fieldName"     "countImage9"
        "xpos"          "9999"
        "ypos"          "9999"
        "zpos"          "9"
        "wide"          "30"
        "tall"          "60"
        "visible"       "0"
        "enabled"       "1"
        "image"         ""  
        "scaleImage"    "1" 
    }
    
    "countImage10" [$WIN32]
    {
        "ControlName"   "CTFImagePanel"
        "fieldName"     "countImage10"
        "xpos"          "9999"
        "ypos"          "9999"
        "zpos"          "9"
        "wide"          "30"
        "tall"          "60"
        "visible"       "0"
        "enabled"       "1"
        "image"         ""  
        "scaleImage"    "1" 
    }
    
    "CountLabel" [$WIN32]
    {
        "ControlName"   "CExLabel"
        "fieldName"     "CountLabel"
        "xpos"          "9999"
        "ypos"          "9999"
        "zpos"          "10"
        "wide"          "150"
        "tall"          "18"
        "autoResize"    "1"
        "pinCorner"     "2"
        "visible"       "1"
        "enabled"       "1"
        "tabPosition"   "0"
        "labelText"     "#TF_TeamCount"
        "textAlignment" "left"
        "font"          "HudFontMediumSmallSecondary"
        "fgcolor"       "TanLight"
    }
    
    "numScout" [$WIN32]
    {
        "ControlName"   "CExLabel"
        "fieldName"     "numScout"
        "xpos"          "c33"
        "ypos"          "170"
        "zpos"          "5"
        "wide"          "100"
        "tall"          "16"
        "autoResize"    "1"
        "pinCorner"     "2"
        "visible"       "1"
        "enabled"       "1"
        "tabPosition"   "0"
        "labelText"     "%numScout%"
        "textAlignment" "west"
        "font"          "CerbeticaBold16"
        "fgcolor"       "TanLight"
    }   
    
    "numSoldier" [$WIN32]
    {
        "ControlName"   "CExLabel"
        "fieldName"     "numSoldier"
        "xpos"          "c33"
        "ypos"          "184"
        "zpos"          "5"
        "wide"          "100"
        "tall"          "16"
        "autoResize"    "1"
        "pinCorner"     "2"
        "visible"       "1"
        "enabled"       "1"
        "tabPosition"   "0"
        "labelText"     "%numSoldier%"
        "textAlignment" "west"
        "font"          "CerbeticaBold16"
        "fgcolor"       "TanLight"
    }   
    
    "numPyro" [$WIN32]
    {
        "ControlName"   "CExLabel"
        "fieldName"     "numPyro"
        "xpos"          "c33"
        "ypos"          "265"
        "zpos"          "5"
        "wide"          "100"
        "tall"          "16"
        "autoResize"    "1"
        "pinCorner"     "2"
        "visible"       "1"
        "enabled"       "1"
        "tabPosition"   "0"
        "labelText"     "%numPyro%"
        "textAlignment" "west"
        "font"          "CerbeticaBold16"
        "fgcolor"       "TanLight"
    }       
    
    "numDemoman" [$WIN32]
    {
        "ControlName"   "CExLabel"
        "fieldName"     "numDemoman"
        "xpos"          "c33"
        "ypos"          "198"
        "zpos"          "5"
        "wide"          "100"
        "tall"          "16"
        "autoResize"    "1"
        "pinCorner"     "2"
        "visible"       "1"
        "enabled"       "1"
        "tabPosition"   "0"
        "labelText"     "%numDemoman%"
        "textAlignment" "west"
        "font"          "CerbeticaBold16"
        "fgcolor"       "TanLight"
    }               
    
    "numHeavy" [$WIN32]
    {
        "ControlName"   "CExLabel"
        "fieldName"     "numHeavy"
        "xpos"          "c33"
        "ypos"          "278"
        "zpos"          "5"
        "wide"          "100"
        "tall"          "16"
        "autoResize"    "1"
        "pinCorner"     "2"
        "visible"       "1"
        "enabled"       "1"
        "tabPosition"   "0"
        "labelText"     "%numHeavy%"
        "textAlignment" "west"
        "font"          "CerbeticaBold16"
        "fgcolor"       "TanLight"
    }                           
    
    "numEngineer" [$WIN32]
    {
        "ControlName"   "CExLabel"
        "fieldName"     "numEngineer"
        "xpos"          "c33"
        "ypos"          "292"
        "zpos"          "5"
        "wide"          "100"
        "tall"          "16"
        "autoResize"    "1"
        "pinCorner"     "2"
        "visible"       "1"
        "enabled"       "1"
        "tabPosition"   "0"
        "labelText"     "%numEngineer%"
        "textAlignment" "west"
        "font"          "CerbeticaBold16"
        "fgcolor"       "TanLight"
    }                       
    
    "numMedic" [$WIN32]
    {
        "ControlName"   "CExLabel"
        "fieldName"     "numMedic"
        "xpos"          "c33"
        "ypos"          "212"
        "zpos"          "5"
        "wide"          "100"
        "tall"          "16"
        "autoResize"    "1"
        "pinCorner"     "2"
        "visible"       "1"
        "enabled"       "1"
        "tabPosition"   "0"
        "labelText"     "%numMedic%"
        "textAlignment" "west"
        "font"          "CerbeticaBold16"
        "fgcolor"       "TanLight"
    }                           
    
    "numSniper" [$WIN32]
    {
        "ControlName"   "CExLabel"
        "fieldName"     "numSniper"
        "xpos"          "c33"
        "ypos"          "306"
        "zpos"          "5"
        "wide"          "100"
        "tall"          "16"
        "autoResize"    "1"
        "pinCorner"     "2"
        "visible"       "1"
        "enabled"       "1"
        "tabPosition"   "0"
        "labelText"     "%numSniper%"
        "textAlignment" "west"
        "font"          "CerbeticaBold16"
        "fgcolor"       "TanLight"
    }                       
    
    "numSpy" [$WIN32]
    {
        "ControlName"   "CExLabel"
        "fieldName"     "numMedic"
        "xpos"          "c33"
        "ypos"          "320"
        "zpos"          "5"
        "wide"          "100"
        "tall"          "16"
        "autoResize"    "1"
        "pinCorner"     "2"
        "visible"       "1"
        "enabled"       "1"
        "tabPosition"   "0"
        "labelText"     "%numSpy%"
        "textAlignment" "west"
        "font"          "CerbeticaBold16"
        "fgcolor"       "TanLight"  
    }       
    
    "MvMUpgradeImageScout"
    {
        "ControlName"   "ImagePanel"
        "fieldName"     "MvMUpgradeImageScout"
        "xpos"          "c-270"
        "ypos"          "30"
        "zpos"          "10"
        "wide"          "10"
        "tall"          "10"
        "visible"       "0"
        "enabled"       "1"
        "image"         "mvm/class_upgraded"
        "scaleImage"    "1"
    }
    
    "MvMUpgradeImageSolider"
    {
        "ControlName"   "ImagePanel"
        "fieldName"     "MvMUpgradeImageSolider"
        "xpos"          "c-220"
        "ypos"          "30"
        "zpos"          "10"
        "wide"          "10"
        "tall"          "10"
        "visible"       "0"
        "enabled"       "1"
        "image"         "mvm/class_upgraded"
        "scaleImage"    "1"
    }
    
    "MvMUpgradeImagePyro" 
    {
        "ControlName"   "ImagePanel"
        "fieldName"     "MvMUpgradeImagePyro" 
        "xpos"          "c-170"
        "ypos"          "30"
        "zpos"          "10"
        "wide"          "10"
        "tall"          "10"
        "visible"       "0"
        "enabled"       "1"
        "image"         "mvm/class_upgraded"
        "scaleImage"    "1"
    }
    
    "MvMUpgradeImageDemoman" 
    {
        "ControlName"   "ImagePanel"
        "fieldName"     "MvMUpgradeImageDemoman" 
        "xpos"          "c-80"
        "ypos"          "30"
        "zpos"          "10"
        "wide"          "10"
        "tall"          "10"
        "visible"       "0"
        "enabled"       "1"
        "image"         "mvm/class_upgraded"
        "scaleImage"    "1"
    }
    
    "MvMUpgradeImageHeavy"
    {
        "ControlName"   "ImagePanel"
        "fieldName"     "MvMUpgradeImageHeavy" 
        "xpos"          "c-30"
        "ypos"          "30"
        "zpos"          "10"
        "wide"          "10"
        "tall"          "10"
        "visible"       "0"
        "enabled"       "1"
        "image"         "mvm/class_upgraded"
        "scaleImage"    "1"
    }
    
    "MvMUpgradeImageEngineer"
    {
        "ControlName"   "ImagePanel"
        "fieldName"     "MvMUpgradeImageEngineer"
        "xpos"          "c20"
        "ypos"          "30"
        "zpos"          "10"
        "wide"          "10"
        "tall"          "10"
        "visible"       "0"
        "enabled"       "1"
        "image"         "mvm/class_upgraded"
        "scaleImage"    "1"
    }
    
    "MvMUpgradeImageMedic"
    {
        "ControlName"   "ImagePanel"
        "fieldName"     "MvMUpgradeImageMedic"
        "xpos"          "c108"
        "ypos"          "30"
        "zpos"          "10"
        "wide"          "10"
        "tall"          "10"
        "visible"       "0"
        "enabled"       "1"
        "image"         "mvm/class_upgraded"
        "scaleImage"    "1"
    }
    
    "MvMUpgradeImageSniper"
    {
        "ControlName"   "ImagePanel"
        "fieldName"     "MvMUpgradeImageSniper"
        "xpos"          "c158"
        "ypos"          "30"
        "zpos"          "10"
        "wide"          "10"
        "tall"          "10"
        "visible"       "0"
        "enabled"       "1"
        "image"         "mvm/class_upgraded"
        "scaleImage"    "1"
    }
    
    "MvMUpgradeImageSpy"
    {
        "ControlName"   "ImagePanel"
        "fieldName"     "MvMUpgradeImageSpy"
        "xpos"          "c208"
        "ypos"          "30"
        "zpos"          "10"
        "wide"          "10"
        "tall"          "10"
        "visible"       "0"
        "enabled"       "1"
        "image"         "mvm/class_upgraded"
        "scaleImage"    "1"
    }

    "StartExplanation"
    {
        "ControlName"   "CExplanationPopup"
        "fieldName"     "StartExplanation"
        "xpos"          "0"
        "ypos"          "0"
        "zpos"          "10000"
        "wide"          "250"
        "tall"          "165"
        "visible"       "0"
        "PaintBackgroundType"   "2"
        "paintbackground" "0"
        "border"        "MainMenuHighlightBorder"
        
        "force_close"   "1"
        "end_x"         "c-170"
        "end_y"         "115"
        "end_wide"      "300"
        "end_tall"      "240"
        "callout_inparents_x"   "c-270"
        "callout_inparents_y"   "40"
        "next_explanation"      "VoucherExplanation"
        
        "TitleLabel"
        {
            "ControlName"   "CExLabel"
            "fieldName"     "TitleLabel"
            "font"          "HudFontSmallBold"
            "labelText"     "#TF_MvM_UpgradeExplanation_Title"
            "textAlignment" "north"
            "xpos"          "20"
            "ypos"          "10"
            "wide"          "260"
            "tall"          "30"
            "autoResize"    "0"
            "pinCorner"     "0"
            "visible"       "1"
            "enabled"       "1"
            "wrap"          "1"
            "fgcolor_override" "46 43 42 255"
        }
        
        "TextLabel"
        {
            "ControlName"   "CExLabel"
            "fieldName"     "TextLabel"
            "font"          "HudFontSmall"
            "labelText"     "#TF_MvM_UpgradeExplanation_Text"
            "textAlignment" "north-west"
            "xpos"          "20"
            "ypos"          "45"
            "wide"          "260"
            "tall"          "170"
            "autoResize"    "0"
            "pinCorner"     "0"
            "visible"       "1"
            "enabled"       "1"
            "wrap"          "1"
            "fgcolor_override" "46 43 42 255"
        }
        
        "CloseButton"
        {
            "ControlName"   "CExImageButton"
            "fieldName"     "CloseButton"
            "xpos"          "280"
            "ypos"          "5"
            "zpos"          "10"
            "wide"          "14"
            "tall"          "14"
            "autoResize"    "0"
            "pinCorner"     "0"
            "visible"       "1"
            "enabled"       "1"
            "tabPosition"   "0"
            "labeltext"     ""
            "font"          "HudFontSmallBold"
            "textAlignment" "center"
            "dulltext"      "0"
            "brighttext"    "0"
            "default"       "0"
            "sound_depressed"   "UI/buttonclick.wav"
            "sound_released"    "UI/buttonclickrelease.wav"
            "Command"       "close"
            
            "paintbackground"   "0"
            
            "defaultFgColor_override" "46 43 42 255"
            "armedFgColor_override" "200 80 60 255"
            "depressedFgColor_override" "46 43 42 255"
            
            "image_drawcolor"   "117 107 94 255"
            "image_armedcolor"  "200 80 60 255"
            "SubImage"
            {
                "ControlName"   "ImagePanel"
                "fieldName"     "SubImage"
                "xpos"          "0"
                "ypos"          "0"
                "zpos"          "1"
                "wide"          "14"
                "tall"          "14"
                "visible"       "1"
                "enabled"       "1"
                "image"         "close_button"
                "scaleImage"    "1"
            }               
        }
    }
    
    "TFPlayerModel"
    {
        "ControlName"   "CTFPlayerModelPanel"
        "fieldName"     "TFPlayerModel"
        
        "xpos"          "c-50"
        "ypos"          "38"
        "zpos"          "6"     
        "wide"          "120"
        "tall"          "120"
        
        "autoResize"    "0"
        "pinCorner"     "0"
        "visible"       "1"
        "enabled"       "1"
        
        "fov"           "25"
        "allow_rot"     "0"

        "paintbackground" "1"       
        "paintbackgroundenabled" "1"
        "bgcolor_override" "255 255 255 0"
        
        "model"
        {
            "force_pos" "1"

            "angles_x" "0"
            "angles_y" "180"
            "angles_z" "0"
            "origin_x" "320"
            "origin_y" "10"
            "origin_z" "-49"
            "frame_origin_x"    "0"
            "frame_origin_y"    "0"
            "frame_origin_z"    "0"
            "spotlight" "1"
        
            "modelname"     ""
            "vcd"       "class_select.vcd"      
            
            "animation"
            {
                "name"      "PRIMARY"
                "activity"  "ACT_MP_STAND_PRIMARY"
                "default"   "1"
            }
            "animation"
            {
                "name"      "SECONDARY"
                "activity"  "ACT_MP_STAND_SECONDARY"
            }
            "animation"
            {
                "name"      "MELEE"
                "activity"  "ACT_MP_STAND_MELEE"
            }
            "animation"
            {
                "name"      "BUILDING"
                "activity"  "ACT_MP_STAND_BUILDING"
            }
            "animation"
            {
                "name"      "PDA"
                "activity"  "ACT_MP_STAND_PDA"
            }
            "animation"
            {
                "name"      "ITEM1"
                "activity"  "ACT_MP_STAND_ITEM1"
            }                       
            "animation"
            {
                "name"      "ITEM2"
                "activity"  "ACT_MP_STAND_ITEM2"
            }   
            "animation"
            {
                "name"      "MELEE_ALLCLASS"
                "activity"  "ACT_MP_STAND_MELEE_ALLCLASS"
            }                               
        }
    }
    
    "ClassTipsPanel"
    {
        "ControlName"   "CTFClassTipsPanel"
        "fieldName"     "ClassTipsPanel"
        "xpos"          "9999"
        "ypos"          "9999"
        "zpos"          "7"
        "wide"          "235"
        "tall"          "165"
        "autoResize"    "0"
        "pinCorner"     "0"
        "visible"       "1"
        "enabled"       "1"
        "tabPosition"   "0"
    }
    
    "ClassHighlightPanel"
    {
        "ControlName"   "CExplanationPopup"
        "fieldName"     "ClassHighlightPanel"
        "xpos"          "c-75"
        "ypos"          "280"
        "zpos"          "100"
        "wide"          "250"
        "tall"          "170"
        "visible"       "0"
        "PaintBackgroundType"   "2"
        "paintbackground" "0"
        "border"        "MainMenuHighlightBorder"
        
        "start_x"       "c-238"
        "start_y"       "100"
        "start_wide"    "1"
        "start_tall"    "1"
        "end_x"         "c-325"
        "end_y"         "250"
        "end_wide"      "275"
        "end_tall"      "150"
        "callout_inparents_x"   "c-210"
        "callout_inparents_y"   "437"
        
        "TitleLabel"
        {
            "ControlName"   "CExLabel"
            "fieldName"     "TitleLabel"
            "font"          "HudFontSmallBold"
            "labelText"     "#CMenu_ClassHighlightPanel_Title"
            "textAlignment" "north-west"
            "xpos"          "10"
            "ypos"          "10"
            "wide"          "210"
            "tall"          "20"
            "autoResize"    "0"
            "pinCorner"     "0"
            "visible"       "1"
            "enabled"       "1"
            "wrap"          "1"
            "fgcolor_override" "46 43 42 255"
        }
        
        "ClassHighlightText"
        {
            "ControlName"   "CExLabel"
            "fieldName"     "ClassHighlightText"
            "font"          "HudFontSmall"
            "labelText"     "%ClassHighlightText%"
            "textAlignment" "north-west"
            "xpos"          "20"
            "ypos"          "30"
            "wide"          "210"
            "tall"          "115"
            "autoResize"    "0"
            "pinCorner"     "0"
            "visible"       "1"
            "enabled"       "1"
            "wrap"          "1"
            "fgcolor_override" "46 43 42 255"
        }
        
        "CloseButton"
        {
            "ControlName"   "CExImageButton"
            "fieldName"     "CloseButton"
            "xpos"          "255"
            "ypos"          "5"
            "zpos"          "10"
            "wide"          "14"
            "tall"          "14"
            "autoResize"    "0"
            "pinCorner"     "0"
            "visible"       "1"
            "enabled"       "1"
            "tabPosition"   "0"
            "labeltext"     ""
            "font"          "HudFontSmallBold"
            "textAlignment" "center"
            "dulltext"      "0"
            "brighttext"    "0"
            "default"       "1"
            "sound_depressed"   "UI/buttonclick.wav"
            "sound_released"    "UI/buttonclickrelease.wav"
            "Command"       "close"
            
            "paintbackground"   "0"
            
            "defaultFgColor_override" "46 43 42 255"
            "armedFgColor_override" "235 226 202 255"
            "depressedFgColor_override" "46 43 42 255"
            
            "image_drawcolor"   "117 107 94 255"
            "image_armedcolor"  "200 80 60 255"
            "SubImage"
            {
                "ControlName"   "ImagePanel"
                "fieldName"     "SubImage"
                "xpos"          "0"
                "ypos"          "0"
                "zpos"          "1"
                "wide"          "14"
                "tall"          "14"
                "visible"       "1"
                "enabled"       "1"
                "image"         "close_button"
                "scaleImage"    "1"
            }               
        }
    }       
}
